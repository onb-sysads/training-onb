package com.dao;

public class DataAccessException extends Exception {


	public DataAccessException() {
		// TODO Auto-generated constructor stub
	}

	public DataAccessException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public DataAccessException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public DataAccessException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
